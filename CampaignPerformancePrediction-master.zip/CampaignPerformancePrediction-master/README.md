# CampaignPerformancePrediction
Analysing campaign by prediction performance (impressions, clicks, conversions) using machine learning.

(Please read SubmissionWriteUp file in workfile folder to understand the solution better)
